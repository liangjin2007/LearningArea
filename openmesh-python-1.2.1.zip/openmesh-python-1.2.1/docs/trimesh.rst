
*******
TriMesh
*******

.. autoclass:: openmesh.TriMesh
   :members:
