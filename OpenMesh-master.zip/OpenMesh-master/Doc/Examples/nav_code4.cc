// Get the face adjacent to the opposite halfedge
OpenMesh::PolyConnectivity::opposite_face_handle();

// Get the handle to the opposite halfedge
OpenMesh::Concepts::KernelT::opposite_halfedge_handle();

// Get the opposite vertex to the opposite halfedge
OpenMesh::TriConnectivity::opposite_he_opposite_vh();

// Get the vertex assigned to the opposite halfedge
OpenMesh::TriConnectivity::opposite_vh();
